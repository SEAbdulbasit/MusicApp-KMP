/*
 * Copyright 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      http://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */

package androidx.compose.ui.focus

import androidx.compose.ui.Modifier
import androidx.compose.ui.internal.JvmDefaultWithCompatibility
import androidx.compose.ui.node.ModifierNodeElement
import androidx.compose.ui.platform.InspectorInfo

/** A [modifier][Modifier.Element] that can be used to observe focus state events. */
@Deprecated("Use FocusEventModifierNode instead")
@JvmDefaultWithCompatibility
interface FocusEventModifier : Modifier.Element {
    /** A callback that is called whenever the focus system raises events. */
    fun onFocusEvent(focusState: FocusState)
}

/** Add this modifier to a component to observe focus state events. */
fun Modifier.onFocusEvent(onFocusEvent: (FocusState) -> Unit): Modifier =
    this then FocusEventElement(onFocusEvent)

private class FocusEventElement(val onFocusEvent: (FocusState) -> Unit) :
    ModifierNodeElement<FocusEventNode>() {
    override fun create() = FocusEventNode(onFocusEvent)

    override fun update(node: FocusEventNode) {
        node.onFocusEvent = onFocusEvent
    }

    override fun InspectorInfo.inspectableProperties() {
        name = "onFocusEvent"
        properties["onFocusEvent"] = onFocusEvent
    }

    override fun equals(other: Any?): Boolean {
        if (this === other) return true
        if (other !is FocusEventElement) return false

        if (onFocusEvent !== other.onFocusEvent) return false

        return true
    }

    override fun hashCode(): Int {
        return onFocusEvent.hashCode()
    }
}

private class FocusEventNode(var onFocusEvent: (FocusState) -> Unit) :
    FocusEventModifierNode, Modifier.Node() {

    override fun onFocusEvent(focusState: FocusState) {
        this.onFocusEvent.invoke(focusState)
    }
}
